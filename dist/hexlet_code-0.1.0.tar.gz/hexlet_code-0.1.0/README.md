### Hexlet tests and linter status:
[![Actions Status](https://github.com/eleron96/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/eleron96/python-project-50/actions)
### Maintainability Badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/ae82db826b8a6d6f28f6/maintainability)](https://codeclimate.com/github/eleron96/python-project-50/maintainability)
### Test Coverage Badge:
[![Test Coverage](https://api.codeclimate.com/v1/badges/ae82db826b8a6d6f28f6/test_coverage)](https://codeclimate.com/github/eleron96/python-project-50/test_coverage)
