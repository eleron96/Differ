import argparse

parser = argparse.ArgumentParser()
parser.parse_args()

args = parser.parse_args()