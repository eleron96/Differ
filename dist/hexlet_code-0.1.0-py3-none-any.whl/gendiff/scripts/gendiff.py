import argparse
import diff_json


def main():
    parser = argparse.ArgumentParser(prog='gendiff',
                                     description='Compares two configuration files and shows a difference.')
    parser.add_argument('first_file', help='First file to compare')
    parser.add_argument('second_file', help='Second file to compare')
    parser.add_argument('-f', '--format', dest='format', default='pretty', help='set format of output')

    args = parser.parse_args()
    print(diff_json.compare_files())
    print(args)


if __name__ == '__main__':
    main()
